// Background Script (Manifest V3 - ES Module) - Persistent WebSocket

let socket = null;
let isConnected = false;
let retryInterval = 1000;
let explicitPort = 6969;

// Initialize
chrome.runtime.onStartup.addListener(connect);
chrome.runtime.onInstalled.addListener(connect);
connect();

async function connect() {
    if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) return;

    const config = await chrome.storage.local.get({ serverPort: 6969 });
    explicitPort = config.serverPort;

    // Use 127.0.0.1 instead of localhost to avoid IPv6 resolution issues
    const wsUrl = `ws://127.0.0.1:${explicitPort}`;
    console.log(`Attempting WS connection to ${wsUrl}...`);

    try {
        socket = new WebSocket(wsUrl);

        socket.onopen = () => {
            console.log("✅ WebSocket Connected!");
            isConnected = true;
            retryInterval = 1000; // Reset retry
            updateActionIcon(true);
            chrome.runtime.sendMessage({ action: 'status_update', connected: true });
        };

        socket.onclose = () => {
            console.log("❌ WebSocket Disconnected. Retrying...");
            isConnected = false;
            updateActionIcon(false);
            chrome.runtime.sendMessage({ action: 'status_update', connected: false });
            socket = null;

            // Random jitter to avoid hammering
            setTimeout(connect, retryInterval);
            retryInterval = Math.min(retryInterval * 1.5, 10000); // Exponential backoff max 10s
        };

        socket.onerror = (e) => {
            console.error("WS Error", e);
            socket.close(); // Ensure clean close triggers retry
        };

        socket.onmessage = (event) => {
            const data = JSON.parse(event.data);
            if (data.type === 'ACK') {
                notify("Sent!", "Download started in app.");
            }
        };

    } catch (e) {
        console.error("Connection failed", e);
        setTimeout(connect, 5000);
    }
}

function updateActionIcon(connected) {
    if (connected) {
        chrome.action.setBadgeText({ text: "ON" });
        chrome.action.setBadgeBackgroundColor({ color: "#00b894" });
    } else {
        chrome.action.setBadgeText({ text: "" }); // or "OFF"
    }
}

// Handle Messages from Popup or Content Script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'download_current_page') {
        sendDownload(message.url);
    } else if (message.action === 'get_status') {
        sendResponse({ connected: isConnected, port: explicitPort });
    } else if (message.action === 'force_reconnect') {
        console.log("Force reconnect requested");
        if (socket) socket.close();
        isConnected = false;
        connect();
    }
    return true; // Keep channel open
});

async function sendDownload(url) {
    if (!isConnected || !socket) {
        notify("Not Connected", "Waiting for App connection...");
        // Try to connect once immediately
        connect();
        return;
        // Or should we fallback to protocol? 
        // Let's stick to WS as requested "Zero Conf" implies reliance on the connection.
    }

    // Get Cookies
    let cookieString = "";
    try {
        const urlObj = new URL(url);
        const cookies = await chrome.cookies.getAll({ domain: urlObj.hostname });
        if (cookies && cookies.length > 0) {
            cookieString = cookies.map(c => `${c.name}=${c.value}`).join('; ');
        }
    } catch (e) { console.warn("Cookie fetch failed", e); }

    const payload = {
        type: 'DOWNLOAD',
        url: url,
        cookies: cookieString,
        userAgent: navigator.userAgent
    };

    socket.send(JSON.stringify(payload));
}

function notify(title, message) {
    chrome.notifications.create({
        type: "basic",
        iconUrl: "icons/icon-48.png",
        title: title,
        message: message
    });
}
