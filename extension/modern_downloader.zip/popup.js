document.addEventListener('DOMContentLoaded', async () => {
    const downloadBtn = document.getElementById('downloadBtn');
    const openAppBtn = document.getElementById('openAppBtn');
    const pageTitleToDisplay = document.getElementById('pageTitle');
    const pageUrlToDisplay = document.getElementById('pageUrl');
    const pageIcon = document.getElementById('pageIcon');
    const statusDot = document.querySelector('.status-dot');
    const statusText = document.getElementById('statusText');

    // 1. Initial Status Check (Ask Background)
    checkStatus();

    // 2. Poll status slightly for instant UI feedback (or listen for push if refined)
    setInterval(checkStatus, 1000);

    function checkStatus() {
        chrome.runtime.sendMessage({ action: 'get_status' }, (response) => {
            if (chrome.runtime.lastError) {
                statusText.textContent = "Error: " + chrome.runtime.lastError.message;
                return;
            }
            // response might be undefined if background is waking up
            if (response && response.connected) {
                statusDot.style.background = '#00b894'; // Green
                statusDot.title = "Connected (WS)";
                statusText.textContent = `Connected (:${response.port})`;
            } else {
                statusDot.style.background = '#d63031'; // Red
                statusDot.title = "Disconnected";
                statusText.textContent = `Click to Retry (:${response?.port || 6969})`;
            }
        });
    }

    statusText.addEventListener('click', () => {
        statusText.textContent = "Retrying invalidation...";
        chrome.runtime.sendMessage({ action: 'force_reconnect' });
        setTimeout(checkStatus, 1000);
    });

    // Auto-Fetch Tab Info...
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (tab) {
        if (tab.title) pageTitleToDisplay.textContent = tab.title;
        if (tab.url) {
            try {
                const urlObj = new URL(tab.url);
                pageUrlToDisplay.textContent = urlObj.hostname + (urlObj.pathname.length > 20 ? urlObj.pathname.substring(0, 20) + '...' : urlObj.pathname);
            } catch (e) {
                pageUrlToDisplay.textContent = tab.url;
            }
        }
        if (tab.favIconUrl) {
            pageIcon.src = tab.favIconUrl;
            pageIcon.style.display = 'block';
        }
    }

    // Action Logic
    downloadBtn.addEventListener('click', () => {
        if (tab && tab.url) {
            chrome.runtime.sendMessage({
                action: 'download_current_page',
                url: tab.url
            });

            // Optimistic UI
            const btnContent = downloadBtn.querySelector('.btn-content');
            btnContent.innerHTML = `<span>Sending...</span>`;
            downloadBtn.style.background = '#00b894';

            setTimeout(() => { window.close(); }, 800);
        }
    });

    // Open Settings
    document.getElementById('openSettings').addEventListener('click', () => {
        chrome.runtime.openOptionsPage();
    });

    openAppBtn.addEventListener('click', () => {
        chrome.tabs.create({ url: 'moderndownloader://open', active: false });
        window.close();
    });
});
