/**
 * Modern Downloader - Content Script
 * Detects videos and injects a discreet download button.
 * Smart URL logic for Twitter/X.
 */

// Configuration
const BUTTON_ID = 'modern-downloader-overlay-btn';
let currentOverlay = null;

// --- Icon SVG ---
const EXPORT_ICON = `
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
  <polyline points="7 10 12 15 17 10"></polyline>
  <line x1="12" y1="15" x2="12" y2="3"></line>
</svg>
`;

/**
 * Creates the overlay button.
 */
function createOverlayButton() {
    if (document.getElementById(BUTTON_ID)) return document.getElementById(BUTTON_ID);

    const btn = document.createElement('div');
    btn.id = BUTTON_ID;
    btn.innerHTML = EXPORT_ICON;

    Object.assign(btn.style, {
        position: 'absolute',
        top: '0',
        left: '0',
        zIndex: '2147483647', // Max Z-Index
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
        borderRadius: '50%',
        width: '40px',
        height: '40px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        cursor: 'pointer',
        opacity: '0',
        transition: 'all 0.2s ease',
        pointerEvents: 'auto',
        backdropFilter: 'blur(4px)',
        boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
        border: '1px solid rgba(255,255,255,0.1)'
    });

    btn.onmouseenter = () => {
        btn.style.opacity = '1';
        btn.style.backgroundColor = '#6C5CE7';
        btn.style.transform = 'scale(1.1)';
    };
    btn.onmouseleave = () => {
        btn.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
        btn.style.transform = 'scale(1)';
    };

    btn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();

        // --- Smart URL Logic ---
        let targetUrl = window.location.href;

        // 1. Twitter/X Handling
        if (targetUrl.includes('x.com') || targetUrl.includes('twitter.com')) {
            const video = btn.dataset.targetVideo ? document.querySelector(`[data-md-id="${btn.dataset.targetVideo}"]`) : null;
            if (video) {
                // Attempt to find the tweet container
                const tweetArticle = video.closest('article');
                if (tweetArticle) {
                    // Find the timestamp/permalink link
                    // Usually <time> parent or <a href="/user/status/123...">
                    const timeElement = tweetArticle.querySelector('time');
                    if (timeElement) {
                        const permalink = timeElement.closest('a');
                        if (permalink && permalink.href) {
                            targetUrl = permalink.href;
                            console.log("Modern Downloader: Found Tweet Permalink:", targetUrl);
                        }
                    }
                }
            }
        }
        // 2. YouTube Shorts (redirect to watch for better compatibility?)
        // Generally yt-dlp handles /shorts/ fine, so we keep page URL.

        // Send to background
        chrome.runtime.sendMessage({
            action: 'download_current_page',
            url: targetUrl
        });

        // Feedback animation
        btn.innerHTML = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
        btn.style.backgroundColor = '#00b894';
        setTimeout(() => {
            btn.innerHTML = EXPORT_ICON;
            btn.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
        }, 1500);
    };

    document.body.appendChild(btn);
    return btn;
}

/**
 * Positions overlay on video.
 */
function positionOverlay(video) {
    if (!video) return;

    // Assign a temp ID to track relationship for smart URL logic
    if (!video.dataset.mdId) {
        video.dataset.mdId = Math.random().toString(36).substr(2, 9);
    }

    const rect = video.getBoundingClientRect();
    if (rect.width < 100 || rect.height < 100) return; // Ignore thumbnails

    if (!currentOverlay) {
        currentOverlay = createOverlayButton();
    }

    currentOverlay.dataset.targetVideo = video.dataset.mdId;

    const scrollX = window.scrollX || window.pageXOffset;
    const scrollY = window.scrollY || window.pageXOffset; // Corrected typo in logic if present

    // Position: Top-Left corner of video
    currentOverlay.style.top = `${rect.top + window.scrollY + 12}px`;
    currentOverlay.style.left = `${rect.left + window.scrollX + 12}px`;
    currentOverlay.style.opacity = '1';
}

function attachListeners(video) {
    if (video.dataset.mdListenerAttached) return;
    video.dataset.mdListenerAttached = 'true';

    video.addEventListener('mouseenter', () => positionOverlay(video));

    // Also re-position on scroll/resize slightly? expensive but useful.
    // For now rely on hover.
}

// Initial Scan
document.querySelectorAll('video').forEach(attachListeners);

// Mutation Observer
const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
            if (node.nodeType === 1) {
                if (node.tagName === 'VIDEO') attachListeners(node);
                else node.querySelectorAll && node.querySelectorAll('video').forEach(attachListeners);
            }
        }
    }
});
observer.observe(document.body, { childList: true, subtree: true });

// Global mouse listener to hide overlay if we move far away?
// Simpler: Just hide when mouse leaves the specific video?
// Implementation:
document.addEventListener('mouseover', (e) => {
    // If hovering video or button, keep. Else hide.
    const isVideo = e.target.tagName === 'VIDEO';
    const isOverlay = e.target.id === BUTTON_ID || e.target.closest(`#${BUTTON_ID}`);

    if (isVideo) {
        // Handled by mouseenter
    } else if (isOverlay) {
        // Keep visible
    } else {
        // Problem: This hides it instantly if we hover a div ON TOP of video (like custom controls)
        // Better: Use the video's mouseleave, but check if entering button.
    }
});
// Actually, simplistic approach: Show on video hover. Hide when hovering something else that ISN'T the button?
// Let's stick to the previous simple logic but improved visibility.
// The button creates itself on body.
