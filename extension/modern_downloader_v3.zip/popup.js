document.addEventListener('DOMContentLoaded', async () => {
    const statusText = document.getElementById('statusText');
    const dot = document.getElementById('statusDot');
    const downloadBtn = document.getElementById('downloadBtn');

    // 1. Check Background Status
    chrome.runtime.sendMessage({ action: "get_status" }, (res) => {
        if (res && res.connected) {
            setConnected();
        } else {
            setDisconnected();
        }
    });

    // 2. Tab Info
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
        document.getElementById('pageTitle').textContent = tab.title || "Unknown Page";
    }

    // 3. Download Action
    downloadBtn.addEventListener('click', () => {
        if (tab && tab.url) {
            chrome.runtime.sendMessage({ action: "download", url: tab.url });
            window.close();
        }
    });

    // 4. Retry Action
    statusText.addEventListener('click', () => {
        statusText.textContent = "Reconnecting...";
        chrome.runtime.sendMessage({ action: "reconnect" });
        setTimeout(() => {
            chrome.runtime.sendMessage({ action: "get_status" }, (res) => {
                if (res && res.connected) setConnected();
                else setDisconnected();
            });
        }, 1000);
    });

    function setConnected() {
        dot.style.background = "#00b894";
        statusText.textContent = "Connected";
        downloadBtn.disabled = false;
        downloadBtn.style.opacity = "1";
    }

    function setDisconnected() {
        dot.style.background = "#d63031";
        statusText.textContent = "Disconnected (Click to Retry)";
        // Check 127.0.0.1 explicitly to see if it's reachable via HTTP
        fetch("http://127.0.0.1:6969/status")
            .then(r => {
                if (r.ok) statusText.textContent = "Server OK but WS Failed";
            })
            .catch(e => {
                statusText.textContent = "Server Unreachable (Click to Retry)";
            });
    }
});
