// Saves options to chrome.storage
function saveOptions() {
    const port = document.getElementById('port').value;
    const token = document.getElementById('token').value;

    chrome.storage.local.set({
        serverPort: port,
        apiToken: token
    }, () => {
        // Update status to let user know options were saved.
        const status = document.getElementById('status');
        status.style.display = 'block';
        setTimeout(() => {
            status.style.display = 'none';
        }, 2000);
    });
}

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
function restoreOptions() {
    chrome.storage.local.get({
        serverPort: 6969,
        apiToken: ''
    }, (items) => {
        document.getElementById('port').value = items.serverPort;
        document.getElementById('token').value = items.apiToken;
    });
}

document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save').addEventListener('click', saveOptions);
