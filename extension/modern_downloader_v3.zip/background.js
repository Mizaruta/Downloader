// Modern Downloader V3 - Minimal Background Script

const PORT = 6969;
const WS_URL = `ws://127.0.0.1:${PORT}`;
let socket = null;
let isConnected = false;

function connect() {
    if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) return;

    console.log(`[MD] Connecting to ${WS_URL}...`);
    socket = new WebSocket(WS_URL);

    socket.onopen = () => {
        console.log("[MD] Connected!");
        isConnected = true;
        chrome.action.setBadgeText({ text: "ON" });
        chrome.action.setBadgeBackgroundColor({ color: "#00b894" });
    };

    socket.onclose = () => {
        console.log("[MD] Disconnected. Retrying in 2s...");
        isConnected = false;
        socket = null;
        chrome.action.setBadgeText({ text: "" });
        setTimeout(connect, 2000);
    };

    socket.onerror = (e) => {
        console.error("[MD] Error:", e);
    };
}

// Initial Connection
connect();

// Message Handling
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === "get_status") {
        sendResponse({ connected: isConnected });
    } else if (msg.action === "download") {
        sendDownload(msg.url);
        sendResponse({ sent: true });
    } else if (msg.action === "reconnect") {
        if (socket) socket.close();
        connect();
        sendResponse({ status: "reconnecting" });
    }
    return true;
});

async function sendDownload(url) {
    if (!isConnected) {
        // Fallback to Protocol if WS fails? For now, just try to connect.
        connect();
        return;
    }

    // Get Cookies
    let cookiesStr = "";
    try {
        const urlObj = new URL(url);
        const cookies = await chrome.cookies.getAll({ domain: urlObj.hostname });
        cookiesStr = cookies.map(c => `${c.name}=${c.value}`).join('; ');
    } catch (e) { }

    const payload = {
        type: 'DOWNLOAD',
        url: url,
        cookies: cookiesStr,
        userAgent: navigator.userAgent
    };

    socket.send(JSON.stringify(payload));
}
